/**
 * Button
 */

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './Button20.css';
import classNames from 'classnames';
import Loader from '../Loader/Loader';
import { fireAnalyticsEvent } from '../../utils/omniture/omniture';


const propTypes = {
  type: PropTypes.oneOf( ['submit', 'button', 'reset'] ),
  btnStyle: PropTypes.oneOf( ['primary', 'secondary', 'tertiary', 'ghost', 'icon', 'link'] ),
  size: PropTypes.oneOf( ['small', 'medium', 'large'] ),
  block: PropTypes.bool,
  disabled: PropTypes.bool,
  showLoader: PropTypes.bool,
  tabIndex: PropTypes.number,
  id: PropTypes.string,
  dataNavDescription: PropTypes.string,
  clickEventHandler: PropTypes.func,
  analyticsEvent: PropTypes.object, // see SamplesList.jsx for data object implementation
  componentMountedHandler: PropTypes.func,
  ariaPressed: PropTypes.bool,
  ariaLabel: PropTypes.string,
  ariaSelected: PropTypes.bool,
  ariaControls: PropTypes.string,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  srOnly: PropTypes.bool


}

const defaultProps = {
  showLoader: false,
  disabled: false,
  block: false,
  srOnly: false
}



/**
 * Class
 * @extends React.Component
 */
class Button20 extends Component{

  constructor( props ){
    super();
    this.focus = this.focus.bind( this );
  }

  input = undefined;

  focus(){
    this.input.focus();
  }

  componentDidMount(){
    if( this.props.componentMountedHandler ){
      this.props.componentMountedHandler();
    }
  }


  /**
   * Renders the Button component
   */
  render(){

    return (
      <button
        { ...( this.props.dataNavDescription && { 'data-nav-description': this.props.dataNavDescription } ) }
        { ...( this.props.id && { id: this.props.id } ) }
        { ...( this.props.ariaSelected && { 'aria-selected' : this.props.ariaSelected } ) }
        { ...( this.props.ariaPressed && { 'aria-pressed' : this.props.ariaPressed } ) }
        { ...( this.props.ariaControls && { 'aria-controls' : this.props.ariaControls } ) }
        { ...( this.props.ariaLabel && { 'aria-label' : this.props.ariaLabel } ) }
        { ...( this.props.onFocus && { onFocus: this.props.onFocus } ) }
        { ...( this.props.onBlur && { onBlur: this.props.onBlur } ) }
        { ...( this.props.type && { type: this.props.type } ) }
        { ...( this.props.tabIndex && { tabIndex: this.props.tabIndex } ) }
        { ...( this.props.disabled && { 'disabled': this.props.showLoader || this.props.disabled } ) }

        className={
          classNames( 'Button', {
            [`Button__${this.props.btnStyle}`]: this.props.btnStyle,
            [`Button--${this.props.size}`]: this.props.size,
            'Button--block': this.props.block,
            'sr-only': this.props.srOnly
          } )
        }
        { ...( ( this.props.analyticsEvent || this.props.clickEventHandler ) &&
          {
            onClick: ( e )=> {
              if( this.props.analyticsEvent !== undefined ){
                fireAnalyticsEvent( this.props.analyticsEvent.eventName, this.props.analyticsEvent.data );
              }
              if( this.props.clickEventHandler ){
                this.props.clickEventHandler( e );
              }
            }
          }
        ) }
        ref={ ( input ) => {
          this.input = input;
        } }
      >
        { this.props.showLoader && <Loader loaderType='spinner'/> }
        { !this.props.showLoader && this.props.children }

      </button>
    );
  }
}

Button20.propTypes = propTypes;
Button20.defaultProps = defaultProps;

export default Button20;
